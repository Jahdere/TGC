#Rayon Kael'thas
INSERT INTO spell_script_target (entry, type, targetEntry) VALUES (36089, 1 , 19622);
INSERT INTO spell_script_target (entry, type, targetEntry) VALUES (36090, 1 , 19622);

#Trigger Rayon
UPDATE creature_template SET inhabitType = 7 WHERE entry = 20602;